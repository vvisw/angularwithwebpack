const HtmlWebpackPlugin = require('html-webpack-plugin'); //installed via npm
const webpack = require('webpack'); //to access built-in plugins

const path = require('path');


const config = {
  entry: './src/main.ts',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'webpack.bundle.js'
  },
  module: {
    rules:[

        {
            "test": /\.html$/,
            "loader": "raw-loader"
        },
          
        {
                test: /\.ts$/,
                loaders: [
                {
                    "loader":"angular2-template-loader"
                },
                 {
                 "loader": "ts-loader"
                },
                 ],
         },
         {
            test: /\.scss$/,
            use: [
            {
                loader: "style-loader" // creates style nodes from JS strings 
            }, 
            {
                loader: "css-loader" // translates CSS into CommonJS 
            }, 
            {
                loader: "sass-loader" // compiles Sass to CSS 
            },
        ]
        },

        

    ]
  },
  plugins: [
   // new webpack.optimize.UglifyJsPlugin(),
   new HtmlWebpackPlugin({template: './src/index.html'}),
   

  ],
  resolve: {
    extensions: ['.ts', '.js']
  },

};

module.exports = config;