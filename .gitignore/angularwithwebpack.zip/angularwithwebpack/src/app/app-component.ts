import {Component } from '@angular/core';

@Component({

     selector:'main-app',
     templateUrl:'./app.component.html',

})

export class AppComponent{
    title = "my Custom Webpack build";
}
